export default {
  nav: {
    home: "Início",
    gallery: "Galeria",
    about: "Sobre Nós",
    contact: "Contacto",
    book: "Reservar Tour",
  },
  home: {
    heroTitle: "Descubra Lisboa Através do Seu Doce Mais Icónico",
    heroSubtitle:
      "Prove, compare e descubra os melhores Pastéis de Nata de Lisboa numa experiência gastronómica local pensada para os amantes de pastelaria.",
    bookYourTour: "Reserve o Seu Tour",
    exploreExperience: "Explorar a Experiência",
    scroll: "Deslize",
    videoTitle: "Mais Do Que Um Doce. É Uma Experiência Lisboeta.",
    elementsEyebrow: "Os Elementos",
    elementsTitle: "O Que Faz Um Grande Pastel de Nata?",
    elementsSubtitle:
      "Não é apenas creme numa massa. É uma harmonia precisa de calor, técnica e tradição.",
    bakeTitle: "A Cozedura",
    bakeText:
      "Cozido a temperaturas muito elevadas, criando as característica manchas escuras que trazem o contraste amargo necessário ao recheio doce.",
    pastryTitle: "A Massa",
    pastryText:
      "Camadas estaladiças de massa folhada que têm de estalar audivelmente logo na primeira dentada.",
    custardTitle: "O Creme",
    custardText:
      "Sedoso, não demasiado doce, com subtis notas de limão e canela. Nunca gelatinoso.",
  },
  testimonials: {
    eyebrow: "Testemunhos",
    title: "O Que Dizem os Nossos Convidados",
  },
  footer: {
    tagline:
      "© 2024 Alma de Lisboa. Descubra Lisboa, um Pastel de Nata de cada vez.",
    legal: "Legal",
    privacy: "Política de Privacidade",
    terms: "Termos de Serviço",
    social: "Redes Sociais",
  },
} as const;