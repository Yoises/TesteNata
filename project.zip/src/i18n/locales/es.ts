export default {
  nav: {
    home: "Inicio",
    gallery: "Galería",
    about: "Sobre Nosotros",
    contact: "Contacto",
    book: "Reservar Tour",
  },
  home: {
    heroTitle: "Descubre Lisboa a Través de Su Pastelería Más Icónica",
    heroSubtitle:
      "Prueba, compara y descubre los mejores Pastéis de Nata de Lisboa con una experiencia gastronómica local diseñada para amantes de la repostería.",
    bookYourTour: "Reserva Tu Tour",
    exploreExperience: "Explorar la Experiencia",
    scroll: "Desliza",
    videoTitle: "Más Que Un Pastel. Es Una Experiencia Lisboeta.",
    elementsEyebrow: "Los Elementos",
    elementsTitle: "¿Qué Hace a un Gran Pastel de Nata?",
    elementsSubtitle:
      "No es solo natilla en una masa. Es una armonía precisa de calor, técnica y tradición.",
    bakeTitle: "El Horneado",
    bakeText:
      "Horneado a temperaturas abrasadoras, creando las características manchas oscuras que aportan un contraste amargo necesario al relleno dulce.",
    pastryTitle: "La Masa",
    pastryText:
      "Capas crujientes de hojaldre que deben crujir audiblemente al primer bocado.",
    custardTitle: "La Natilla",
    custardText:
      "Sedosa, no demasiado dulce, con sutiles notas de limón y canela. Nunca gelatinosa.",
  },
  testimonials: {
    eyebrow: "Testimonios",
    title: "De Nuestros Huéspedes",
  },
  footer: {
    tagline:
      "© 2024 Alma de Lisboa. Descubre Lisboa un Pastel de Nata a la vez.",
    legal: "Legal",
    privacy: "Política de Privacidad",
    terms: "Términos de Servicio",
    social: "Redes Sociales",
  },
} as const;