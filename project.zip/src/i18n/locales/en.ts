export default {
  nav: {
    home: "Home",
    gallery: "Gallery",
    about: "About Us",
    contact: "Contact",
    book: "Book a Tour",
  },
  home: {
    heroTitle: "Discover Lisbon Through Its Most Iconic Pastry",
    heroSubtitle:
      "Taste, compare and discover the best Pastéis de Nata in Lisbon with a local food experience designed for pastry lovers.",
    bookYourTour: "Book Your Tour",
    exploreExperience: "Explore the Experience",
    scroll: "Scroll",
    videoTitle: "More Than a Pastry. It's a Lisbon Experience.",
    elementsEyebrow: "The Elements",
    elementsTitle: "What Makes a Great Pastel de Nata?",
    elementsSubtitle:
      "It's not just custard in a crust. It is a precise harmony of heat, technique, and tradition.",
    bakeTitle: "The Bake",
    bakeText:
      "Baked at blistering temperatures, creating the signature dark spots that provide a necessary bitter contrast to the sweet filling.",
    pastryTitle: "The Pastry",
    pastryText:
      "Crisp, shattering layers of puff pastry that must audibly crunch upon the first bite.",
    custardTitle: "The Custard",
    custardText:
      "Silky, not overly sweet, with subtle notes of lemon and cinnamon. Never gelatinous.",
  },
  testimonials: {
    eyebrow: "Testimonials",
    title: "From Our Guests",
  },
  footer: {
    tagline:
      "© 2024 Alma de Lisboa. Discover Lisbon one Pastel de Nata at a time.",
    legal: "Legal",
    privacy: "Privacy Policy",
    terms: "Terms of Service",
    social: "Social",
  },
} as const;