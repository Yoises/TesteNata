export default {
  nav: {
    home: "Accueil",
    gallery: "Galerie",
    about: "À Propos",
    contact: "Contact",
    book: "Réserver",
  },
  home: {
    heroTitle: "Découvrez Lisbonne à Travers Sa Pâtisserie la Plus Emblématique",
    heroSubtitle:
      "Goûtez, comparez et découvrez les meilleurs Pastéis de Nata de Lisbonne lors d'une expérience culinaire locale pensée pour les amateurs de pâtisserie.",
    bookYourTour: "Réservez Votre Tour",
    exploreExperience: "Découvrir l'Expérience",
    scroll: "Défiler",
    videoTitle: "Plus Qu'une Pâtisserie. Une Expérience Lisboète.",
    elementsEyebrow: "Les Éléments",
    elementsTitle: "Qu'est-ce Qui Fait un Grand Pastel de Nata ?",
    elementsSubtitle:
      "Ce n'est pas juste de la crème dans une croûte. C'est une harmonie précise de chaleur, de technique et de tradition.",
    bakeTitle: "La Cuisson",
    bakeText:
      "Cuit à très haute température, créant les taches caractéristiques qui apportent un contraste amer nécessaire à la garniture sucrée.",
    pastryTitle: "La Pâte",
    pastryText:
      "Des couches croustillantes de pâte feuilletée qui doivent craquer audiblement dès la première bouchée.",
    custardTitle: "La Crème",
    custardText:
      "Soyeuse, pas trop sucrée, avec de subtiles notes de citron et de cannelle. Jamais gélatineuse.",
  },
  testimonials: {
    eyebrow: "Témoignages",
    title: "Nos Invités Témoignent",
  },
  footer: {
    tagline:
      "© 2024 Alma de Lisboa. Découvrez Lisbonne, un Pastel de Nata à la fois.",
    legal: "Mentions Légales",
    privacy: "Politique de Confidentialité",
    terms: "Conditions d'Utilisation",
    social: "Réseaux Sociaux",
  },
} as const;